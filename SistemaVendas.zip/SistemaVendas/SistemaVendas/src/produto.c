#include <stdio.h>
#include "produto.h"

// TODO: implementar as funcoes utilizando somente vetores e indices.
//
// Nao utilizar ponteiros.
// A quantidade de produtos e controlada pela variavel quantidadeProdutos
// na main. Como nao ha ponteiros, cadastrarProduto() RETORNA a nova
// quantidade e a main guarda o valor:
//     quantidadeProdutos = cadastrarProduto(produtos, quantidadeProdutos);
//
// Sugestoes:
// cadastrarProduto()
// listarProdutos()
// buscarProduto()
// atualizarEstoque()

int cadastrarProduto(Produto produtos[], int quantidadeProdutos) {
    // TODO: ler os dados do produto e guardar em produtos[quantidadeProdutos]
    // (verificar se ainda cabe no vetor: MAX_PRODUTOS)
    return quantidadeProdutos;  // TODO: retornar a nova quantidade
}

void listarProdutos(Produto produtos[], int quantidadeProdutos) {
    // TODO
}

int buscarProduto(Produto produtos[], int quantidadeProdutos, int codigo) {
    // TODO
    return -1;
}

void atualizarEstoque(Produto produtos[], int indiceProduto, int quantidadeVendida) {
    // TODO
}
