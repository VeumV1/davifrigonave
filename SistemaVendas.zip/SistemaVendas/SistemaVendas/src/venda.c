#include <stdio.h>
#include "venda.h"

// TODO: implementar a venda utilizando vetores e indices.
// Nao utilizar ponteiros.
//
// Uma possibilidade:
// - percorrer o vetor de produtos;
// - perguntar qual produto o cliente deseja;
// - perguntar a quantidade;
// - somar o valor ao total;
// - diminuir a quantidade do estoque;
// - repetir enquanto o cliente desejar adicionar produtos.
//
// Depois:
// - mostrar o total;
// - escolher a forma de pagamento;
// - aplicar as regras de dinheiro, credito ou debito.

void realizarVenda(Produto produtos[], int quantidadeProdutos) {
    // TODO
}

void processarPagamento(float total) {
    // TODO
}
